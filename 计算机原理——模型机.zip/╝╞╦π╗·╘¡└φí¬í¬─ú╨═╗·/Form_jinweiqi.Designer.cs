﻿namespace 超前进位加法器
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.x7 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.x6 = new System.Windows.Forms.TextBox();
            this.x5 = new System.Windows.Forms.TextBox();
            this.x4 = new System.Windows.Forms.TextBox();
            this.x3 = new System.Windows.Forms.TextBox();
            this.x2 = new System.Windows.Forms.TextBox();
            this.x1 = new System.Windows.Forms.TextBox();
            this.x0 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.y6 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.y7 = new System.Windows.Forms.TextBox();
            this.y0 = new System.Windows.Forms.TextBox();
            this.y1 = new System.Windows.Forms.TextBox();
            this.y2 = new System.Windows.Forms.TextBox();
            this.y5 = new System.Windows.Forms.TextBox();
            this.y3 = new System.Windows.Forms.TextBox();
            this.y4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_danbu = new System.Windows.Forms.Button();
            this.btn_finally = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.p6 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.p7 = new System.Windows.Forms.TextBox();
            this.p0 = new System.Windows.Forms.TextBox();
            this.p1 = new System.Windows.Forms.TextBox();
            this.p2 = new System.Windows.Forms.TextBox();
            this.p5 = new System.Windows.Forms.TextBox();
            this.p3 = new System.Windows.Forms.TextBox();
            this.p4 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.g6 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.g7 = new System.Windows.Forms.TextBox();
            this.g0 = new System.Windows.Forms.TextBox();
            this.g1 = new System.Windows.Forms.TextBox();
            this.g2 = new System.Windows.Forms.TextBox();
            this.g5 = new System.Windows.Forms.TextBox();
            this.g3 = new System.Windows.Forms.TextBox();
            this.g4 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.c7 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.c4 = new System.Windows.Forms.TextBox();
            this.c6 = new System.Windows.Forms.TextBox();
            this.c3 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.c5 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.c2 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.c1 = new System.Windows.Forms.TextBox();
            this.c0 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.s7 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.s4 = new System.Windows.Forms.TextBox();
            this.s6 = new System.Windows.Forms.TextBox();
            this.s3 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.s5 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.s2 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.s1 = new System.Windows.Forms.TextBox();
            this.s0 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_output = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.textbox_jieguo = new System.Windows.Forms.TextBox();
            this.btn_ok = new System.Windows.Forms.Button();
            this.intput_y = new System.Windows.Forms.TextBox();
            this.intput_x = new System.Windows.Forms.TextBox();
            this.btn_out = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // x7
            // 
            this.x7.Location = new System.Drawing.Point(200, 45);
            this.x7.Name = "x7";
            this.x7.Size = new System.Drawing.Size(20, 25);
            this.x7.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(17, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "加数x";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "加数y";
            // 
            // x6
            // 
            this.x6.Location = new System.Drawing.Point(249, 45);
            this.x6.Name = "x6";
            this.x6.Size = new System.Drawing.Size(20, 25);
            this.x6.TabIndex = 6;
            // 
            // x5
            // 
            this.x5.Location = new System.Drawing.Point(304, 45);
            this.x5.Name = "x5";
            this.x5.Size = new System.Drawing.Size(20, 25);
            this.x5.TabIndex = 7;
            // 
            // x4
            // 
            this.x4.Location = new System.Drawing.Point(355, 45);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(20, 25);
            this.x4.TabIndex = 8;
            // 
            // x3
            // 
            this.x3.Location = new System.Drawing.Point(411, 45);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(20, 25);
            this.x3.TabIndex = 9;
            // 
            // x2
            // 
            this.x2.Location = new System.Drawing.Point(463, 45);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(20, 25);
            this.x2.TabIndex = 10;
            // 
            // x1
            // 
            this.x1.Location = new System.Drawing.Point(517, 45);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(20, 25);
            this.x1.TabIndex = 11;
            // 
            // x0
            // 
            this.x0.Location = new System.Drawing.Point(567, 45);
            this.x0.Name = "x0";
            this.x0.Size = new System.Drawing.Size(20, 25);
            this.x0.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(220, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "x7";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.y6);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.y7);
            this.groupBox1.Controls.Add(this.y0);
            this.groupBox1.Controls.Add(this.y1);
            this.groupBox1.Controls.Add(this.y2);
            this.groupBox1.Controls.Add(this.y5);
            this.groupBox1.Controls.Add(this.y3);
            this.groupBox1.Controls.Add(this.y4);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.x6);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.x7);
            this.groupBox1.Controls.Add(this.x0);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.x1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.x2);
            this.groupBox1.Controls.Add(this.x5);
            this.groupBox1.Controls.Add(this.x3);
            this.groupBox1.Controls.Add(this.x4);
            this.groupBox1.Location = new System.Drawing.Point(29, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(771, 129);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据加工区";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(593, 81);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 15);
            this.label11.TabIndex = 36;
            this.label11.Text = "y0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(543, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 15);
            this.label12.TabIndex = 35;
            this.label12.Text = "y1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(489, 81);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 15);
            this.label13.TabIndex = 34;
            this.label13.Text = "y2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(275, 81);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 15);
            this.label14.TabIndex = 30;
            this.label14.Text = "y6";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(434, 81);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 15);
            this.label15.TabIndex = 33;
            this.label15.Text = "y3";
            // 
            // y6
            // 
            this.y6.Location = new System.Drawing.Point(249, 78);
            this.y6.Name = "y6";
            this.y6.Size = new System.Drawing.Size(20, 25);
            this.y6.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(381, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 15);
            this.label16.TabIndex = 32;
            this.label16.Text = "y4";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(220, 81);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 15);
            this.label17.TabIndex = 29;
            this.label17.Text = "y7";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(326, 81);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 15);
            this.label18.TabIndex = 31;
            this.label18.Text = "y5";
            // 
            // y7
            // 
            this.y7.Location = new System.Drawing.Point(200, 78);
            this.y7.Name = "y7";
            this.y7.Size = new System.Drawing.Size(20, 25);
            this.y7.TabIndex = 21;
            // 
            // y0
            // 
            this.y0.Location = new System.Drawing.Point(567, 78);
            this.y0.Name = "y0";
            this.y0.Size = new System.Drawing.Size(20, 25);
            this.y0.TabIndex = 28;
            // 
            // y1
            // 
            this.y1.Location = new System.Drawing.Point(517, 78);
            this.y1.Name = "y1";
            this.y1.Size = new System.Drawing.Size(20, 25);
            this.y1.TabIndex = 27;
            // 
            // y2
            // 
            this.y2.Location = new System.Drawing.Point(463, 78);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(20, 25);
            this.y2.TabIndex = 26;
            // 
            // y5
            // 
            this.y5.Location = new System.Drawing.Point(304, 78);
            this.y5.Name = "y5";
            this.y5.Size = new System.Drawing.Size(20, 25);
            this.y5.TabIndex = 23;
            // 
            // y3
            // 
            this.y3.Location = new System.Drawing.Point(411, 78);
            this.y3.Name = "y3";
            this.y3.Size = new System.Drawing.Size(20, 25);
            this.y3.TabIndex = 25;
            // 
            // y4
            // 
            this.y4.Location = new System.Drawing.Point(355, 78);
            this.y4.Name = "y4";
            this.y4.Size = new System.Drawing.Size(20, 25);
            this.y4.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(593, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 15);
            this.label10.TabIndex = 20;
            this.label10.Text = "x0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(543, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 15);
            this.label9.TabIndex = 19;
            this.label9.Text = "x1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(489, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "x2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(275, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 15);
            this.label1.TabIndex = 14;
            this.label1.Text = "x6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(434, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "x3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(381, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "x4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(326, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 15);
            this.label5.TabIndex = 15;
            this.label5.Text = "x5";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_danbu);
            this.groupBox2.Controls.Add(this.btn_finally);
            this.groupBox2.Controls.Add(this.label51);
            this.groupBox2.Controls.Add(this.label52);
            this.groupBox2.Controls.Add(this.label53);
            this.groupBox2.Controls.Add(this.label54);
            this.groupBox2.Controls.Add(this.label55);
            this.groupBox2.Controls.Add(this.p6);
            this.groupBox2.Controls.Add(this.label56);
            this.groupBox2.Controls.Add(this.label57);
            this.groupBox2.Controls.Add(this.label58);
            this.groupBox2.Controls.Add(this.p7);
            this.groupBox2.Controls.Add(this.p0);
            this.groupBox2.Controls.Add(this.p1);
            this.groupBox2.Controls.Add(this.p2);
            this.groupBox2.Controls.Add(this.p5);
            this.groupBox2.Controls.Add(this.p3);
            this.groupBox2.Controls.Add(this.p4);
            this.groupBox2.Controls.Add(this.label59);
            this.groupBox2.Controls.Add(this.label60);
            this.groupBox2.Controls.Add(this.label61);
            this.groupBox2.Controls.Add(this.label62);
            this.groupBox2.Controls.Add(this.label63);
            this.groupBox2.Controls.Add(this.g6);
            this.groupBox2.Controls.Add(this.label64);
            this.groupBox2.Controls.Add(this.label65);
            this.groupBox2.Controls.Add(this.label66);
            this.groupBox2.Controls.Add(this.g7);
            this.groupBox2.Controls.Add(this.g0);
            this.groupBox2.Controls.Add(this.g1);
            this.groupBox2.Controls.Add(this.g2);
            this.groupBox2.Controls.Add(this.g5);
            this.groupBox2.Controls.Add(this.g3);
            this.groupBox2.Controls.Add(this.g4);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.c7);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.c4);
            this.groupBox2.Controls.Add(this.c6);
            this.groupBox2.Controls.Add(this.c3);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.c5);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.c2);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.c1);
            this.groupBox2.Controls.Add(this.c0);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.s7);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.s4);
            this.groupBox2.Controls.Add(this.s6);
            this.groupBox2.Controls.Add(this.s3);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.s5);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.s2);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.s1);
            this.groupBox2.Controls.Add(this.s0);
            this.groupBox2.Location = new System.Drawing.Point(29, 347);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(771, 256);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "进位区";
            // 
            // btn_danbu
            // 
            this.btn_danbu.Location = new System.Drawing.Point(658, 70);
            this.btn_danbu.Name = "btn_danbu";
            this.btn_danbu.Size = new System.Drawing.Size(81, 37);
            this.btn_danbu.TabIndex = 41;
            this.btn_danbu.Text = "单步执行";
            this.btn_danbu.UseVisualStyleBackColor = true;
            this.btn_danbu.Click += new System.EventHandler(this.btn_danbu_Click);
            // 
            // btn_finally
            // 
            this.btn_finally.Location = new System.Drawing.Point(658, 162);
            this.btn_finally.Name = "btn_finally";
            this.btn_finally.Size = new System.Drawing.Size(81, 37);
            this.btn_finally.TabIndex = 41;
            this.btn_finally.Text = "最终执行";
            this.btn_finally.UseVisualStyleBackColor = true;
            this.btn_finally.Click += new System.EventHandler(this.btn_finally_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(593, 195);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(23, 15);
            this.label51.TabIndex = 119;
            this.label51.Text = "p0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(543, 195);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(23, 15);
            this.label52.TabIndex = 118;
            this.label52.Text = "p1";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(489, 195);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(23, 15);
            this.label53.TabIndex = 117;
            this.label53.Text = "p2";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(275, 195);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(23, 15);
            this.label54.TabIndex = 113;
            this.label54.Text = "p6";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(434, 195);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(23, 15);
            this.label55.TabIndex = 116;
            this.label55.Text = "p3";
            // 
            // p6
            // 
            this.p6.Location = new System.Drawing.Point(249, 192);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(20, 25);
            this.p6.TabIndex = 105;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(381, 195);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(23, 15);
            this.label56.TabIndex = 115;
            this.label56.Text = "p4";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(220, 195);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(23, 15);
            this.label57.TabIndex = 112;
            this.label57.Text = "p7";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(326, 195);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(23, 15);
            this.label58.TabIndex = 114;
            this.label58.Text = "p5";
            // 
            // p7
            // 
            this.p7.Location = new System.Drawing.Point(200, 192);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(20, 25);
            this.p7.TabIndex = 104;
            // 
            // p0
            // 
            this.p0.Location = new System.Drawing.Point(567, 192);
            this.p0.Name = "p0";
            this.p0.Size = new System.Drawing.Size(20, 25);
            this.p0.TabIndex = 111;
            // 
            // p1
            // 
            this.p1.Location = new System.Drawing.Point(517, 192);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(20, 25);
            this.p1.TabIndex = 110;
            // 
            // p2
            // 
            this.p2.Location = new System.Drawing.Point(463, 192);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(20, 25);
            this.p2.TabIndex = 109;
            // 
            // p5
            // 
            this.p5.Location = new System.Drawing.Point(304, 192);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(20, 25);
            this.p5.TabIndex = 106;
            // 
            // p3
            // 
            this.p3.Location = new System.Drawing.Point(411, 192);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(20, 25);
            this.p3.TabIndex = 108;
            // 
            // p4
            // 
            this.p4.Location = new System.Drawing.Point(355, 192);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(20, 25);
            this.p4.TabIndex = 107;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(593, 162);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(23, 15);
            this.label59.TabIndex = 103;
            this.label59.Text = "g0";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(543, 162);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(23, 15);
            this.label60.TabIndex = 102;
            this.label60.Text = "g1";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(489, 162);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(23, 15);
            this.label61.TabIndex = 101;
            this.label61.Text = "g2";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(275, 162);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(23, 15);
            this.label62.TabIndex = 97;
            this.label62.Text = "g6";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(434, 162);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(23, 15);
            this.label63.TabIndex = 100;
            this.label63.Text = "g3";
            // 
            // g6
            // 
            this.g6.Location = new System.Drawing.Point(249, 159);
            this.g6.Name = "g6";
            this.g6.Size = new System.Drawing.Size(20, 25);
            this.g6.TabIndex = 89;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(381, 162);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(23, 15);
            this.label64.TabIndex = 99;
            this.label64.Text = "g4";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(220, 162);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(23, 15);
            this.label65.TabIndex = 96;
            this.label65.Text = "g7";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(326, 162);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(23, 15);
            this.label66.TabIndex = 98;
            this.label66.Text = "g5";
            // 
            // g7
            // 
            this.g7.Location = new System.Drawing.Point(200, 159);
            this.g7.Name = "g7";
            this.g7.Size = new System.Drawing.Size(20, 25);
            this.g7.TabIndex = 88;
            // 
            // g0
            // 
            this.g0.Location = new System.Drawing.Point(567, 159);
            this.g0.Name = "g0";
            this.g0.Size = new System.Drawing.Size(20, 25);
            this.g0.TabIndex = 95;
            // 
            // g1
            // 
            this.g1.Location = new System.Drawing.Point(517, 159);
            this.g1.Name = "g1";
            this.g1.Size = new System.Drawing.Size(20, 25);
            this.g1.TabIndex = 94;
            // 
            // g2
            // 
            this.g2.Location = new System.Drawing.Point(463, 159);
            this.g2.Name = "g2";
            this.g2.Size = new System.Drawing.Size(20, 25);
            this.g2.TabIndex = 93;
            // 
            // g5
            // 
            this.g5.Location = new System.Drawing.Point(304, 159);
            this.g5.Name = "g5";
            this.g5.Size = new System.Drawing.Size(20, 25);
            this.g5.TabIndex = 90;
            // 
            // g3
            // 
            this.g3.Location = new System.Drawing.Point(411, 159);
            this.g3.Name = "g3";
            this.g3.Size = new System.Drawing.Size(20, 25);
            this.g3.TabIndex = 92;
            // 
            // g4
            // 
            this.g4.Location = new System.Drawing.Point(355, 159);
            this.g4.Name = "g4";
            this.g4.Size = new System.Drawing.Size(20, 25);
            this.g4.TabIndex = 91;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(17, 202);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(128, 15);
            this.label48.TabIndex = 87;
            this.label48.Text = "Pi为进位传递信号";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(247, 162);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(0, 15);
            this.label47.TabIndex = 86;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(17, 162);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(128, 15);
            this.label46.TabIndex = 85;
            this.label46.Text = "Gi为进位产生信号";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(593, 53);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(23, 15);
            this.label30.TabIndex = 68;
            this.label30.Text = "c0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(543, 53);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(23, 15);
            this.label31.TabIndex = 67;
            this.label31.Text = "c1";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(489, 53);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(23, 15);
            this.label32.TabIndex = 66;
            this.label32.Text = "c2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(275, 53);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(23, 15);
            this.label33.TabIndex = 62;
            this.label33.Text = "c6";
            // 
            // c7
            // 
            this.c7.Location = new System.Drawing.Point(200, 50);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(20, 25);
            this.c7.TabIndex = 53;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(434, 53);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(23, 15);
            this.label34.TabIndex = 65;
            this.label34.Text = "c3";
            // 
            // c4
            // 
            this.c4.Location = new System.Drawing.Point(355, 50);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(20, 25);
            this.c4.TabIndex = 56;
            // 
            // c6
            // 
            this.c6.Location = new System.Drawing.Point(249, 50);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(20, 25);
            this.c6.TabIndex = 54;
            // 
            // c3
            // 
            this.c3.Location = new System.Drawing.Point(411, 50);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(20, 25);
            this.c3.TabIndex = 57;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(381, 53);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(23, 15);
            this.label35.TabIndex = 64;
            this.label35.Text = "c4";
            // 
            // c5
            // 
            this.c5.Location = new System.Drawing.Point(304, 50);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(20, 25);
            this.c5.TabIndex = 55;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(220, 53);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 15);
            this.label36.TabIndex = 61;
            this.label36.Text = "c7";
            // 
            // c2
            // 
            this.c2.Location = new System.Drawing.Point(463, 50);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(20, 25);
            this.c2.TabIndex = 58;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(326, 53);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(23, 15);
            this.label37.TabIndex = 63;
            this.label37.Text = "c5";
            // 
            // c1
            // 
            this.c1.Location = new System.Drawing.Point(517, 50);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(20, 25);
            this.c1.TabIndex = 59;
            // 
            // c0
            // 
            this.c0.Location = new System.Drawing.Point(567, 50);
            this.c0.Name = "c0";
            this.c0.Size = new System.Drawing.Size(20, 25);
            this.c0.TabIndex = 60;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(593, 106);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 15);
            this.label22.TabIndex = 52;
            this.label22.Text = "s0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(543, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 15);
            this.label23.TabIndex = 51;
            this.label23.Text = "s1";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 60);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 15);
            this.label20.TabIndex = 38;
            this.label20.Text = "进位输入C";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(489, 106);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(23, 15);
            this.label24.TabIndex = 50;
            this.label24.Text = "s2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 110);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 15);
            this.label19.TabIndex = 0;
            this.label19.Text = "输出S";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(275, 106);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 15);
            this.label25.TabIndex = 46;
            this.label25.Text = "s6";
            // 
            // s7
            // 
            this.s7.Location = new System.Drawing.Point(200, 103);
            this.s7.Name = "s7";
            this.s7.Size = new System.Drawing.Size(20, 25);
            this.s7.TabIndex = 37;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(434, 106);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(23, 15);
            this.label26.TabIndex = 49;
            this.label26.Text = "s3";
            // 
            // s4
            // 
            this.s4.Location = new System.Drawing.Point(355, 103);
            this.s4.Name = "s4";
            this.s4.Size = new System.Drawing.Size(20, 25);
            this.s4.TabIndex = 40;
            // 
            // s6
            // 
            this.s6.Location = new System.Drawing.Point(249, 103);
            this.s6.Name = "s6";
            this.s6.Size = new System.Drawing.Size(20, 25);
            this.s6.TabIndex = 38;
            // 
            // s3
            // 
            this.s3.Location = new System.Drawing.Point(411, 103);
            this.s3.Name = "s3";
            this.s3.Size = new System.Drawing.Size(20, 25);
            this.s3.TabIndex = 41;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(381, 106);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 15);
            this.label27.TabIndex = 48;
            this.label27.Text = "s4";
            // 
            // s5
            // 
            this.s5.Location = new System.Drawing.Point(304, 103);
            this.s5.Name = "s5";
            this.s5.Size = new System.Drawing.Size(20, 25);
            this.s5.TabIndex = 39;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(220, 106);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(23, 15);
            this.label28.TabIndex = 45;
            this.label28.Text = "s7";
            // 
            // s2
            // 
            this.s2.Location = new System.Drawing.Point(463, 103);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(20, 25);
            this.s2.TabIndex = 42;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(326, 106);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(23, 15);
            this.label29.TabIndex = 47;
            this.label29.Text = "s5";
            // 
            // s1
            // 
            this.s1.Location = new System.Drawing.Point(517, 103);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(20, 25);
            this.s1.TabIndex = 43;
            // 
            // s0
            // 
            this.s0.Location = new System.Drawing.Point(567, 103);
            this.s0.Name = "s0";
            this.s0.Size = new System.Drawing.Size(20, 25);
            this.s0.TabIndex = 44;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(15, 44);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(128, 15);
            this.label49.TabIndex = 38;
            this.label49.Text = "请输入加数以下x:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(15, 95);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(98, 15);
            this.label50.TabIndex = 39;
            this.label50.Text = "请输入加数y:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_out);
            this.groupBox3.Controls.Add(this.btn_output);
            this.groupBox3.Controls.Add(this.label67);
            this.groupBox3.Controls.Add(this.textbox_jieguo);
            this.groupBox3.Controls.Add(this.btn_ok);
            this.groupBox3.Controls.Add(this.intput_y);
            this.groupBox3.Controls.Add(this.intput_x);
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Location = new System.Drawing.Point(31, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(769, 140);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "数据输入(由于位数限制，请两个加数的和不超过256)";
            // 
            // btn_output
            // 
            this.btn_output.Location = new System.Drawing.Point(477, 87);
            this.btn_output.Name = "btn_output";
            this.btn_output.Size = new System.Drawing.Size(127, 30);
            this.btn_output.TabIndex = 45;
            this.btn_output.Text = "最后结果";
            this.btn_output.UseVisualStyleBackColor = true;
            this.btn_output.Click += new System.EventHandler(this.btn_output_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(483, 41);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(52, 15);
            this.label67.TabIndex = 44;
            this.label67.Text = "结果：";
            // 
            // textbox_jieguo
            // 
            this.textbox_jieguo.Location = new System.Drawing.Point(544, 38);
            this.textbox_jieguo.Name = "textbox_jieguo";
            this.textbox_jieguo.Size = new System.Drawing.Size(168, 25);
            this.textbox_jieguo.TabIndex = 43;
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(341, 66);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(88, 25);
            this.btn_ok.TabIndex = 37;
            this.btn_ok.Text = "确定";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // intput_y
            // 
            this.intput_y.Location = new System.Drawing.Point(196, 92);
            this.intput_y.Name = "intput_y";
            this.intput_y.Size = new System.Drawing.Size(100, 25);
            this.intput_y.TabIndex = 42;
            // 
            // intput_x
            // 
            this.intput_x.Location = new System.Drawing.Point(196, 41);
            this.intput_x.Name = "intput_x";
            this.intput_x.Size = new System.Drawing.Size(100, 25);
            this.intput_x.TabIndex = 41;
            // 
            // btn_out
            // 
            this.btn_out.Location = new System.Drawing.Point(656, 87);
            this.btn_out.Name = "btn_out";
            this.btn_out.Size = new System.Drawing.Size(93, 30);
            this.btn_out.TabIndex = 41;
            this.btn_out.Text = "退出";
            this.btn_out.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 614);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "超前进位加法器_lxh";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox x7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox x6;
        private System.Windows.Forms.TextBox x5;
        private System.Windows.Forms.TextBox x4;
        private System.Windows.Forms.TextBox x3;
        private System.Windows.Forms.TextBox x2;
        private System.Windows.Forms.TextBox x1;
        private System.Windows.Forms.TextBox x0;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox y6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox y7;
        private System.Windows.Forms.TextBox y0;
        private System.Windows.Forms.TextBox y1;
        private System.Windows.Forms.TextBox y2;
        private System.Windows.Forms.TextBox y5;
        private System.Windows.Forms.TextBox y3;
        private System.Windows.Forms.TextBox y4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox c7;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox c4;
        private System.Windows.Forms.TextBox c6;
        private System.Windows.Forms.TextBox c3;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox c5;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox c2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox c1;
        private System.Windows.Forms.TextBox c0;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox s7;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox s4;
        private System.Windows.Forms.TextBox s6;
        private System.Windows.Forms.TextBox s3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox s5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox s2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox s1;
        private System.Windows.Forms.TextBox s0;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox intput_y;
        private System.Windows.Forms.TextBox intput_x;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.TextBox textbox_jieguo;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox p6;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox p7;
        private System.Windows.Forms.TextBox p0;
        private System.Windows.Forms.TextBox p1;
        private System.Windows.Forms.TextBox p2;
        private System.Windows.Forms.TextBox p5;
        private System.Windows.Forms.TextBox p3;
        private System.Windows.Forms.TextBox p4;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox g6;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox g7;
        private System.Windows.Forms.TextBox g0;
        private System.Windows.Forms.TextBox g1;
        private System.Windows.Forms.TextBox g2;
        private System.Windows.Forms.TextBox g5;
        private System.Windows.Forms.TextBox g3;
        private System.Windows.Forms.TextBox g4;
        private System.Windows.Forms.Button btn_finally;
        private System.Windows.Forms.Button btn_danbu;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button btn_output;
        private System.Windows.Forms.Button btn_out;
    }
}

