﻿namespace 计算机原理__模型机
{
    partial class Form2
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.richTextBox_input = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.richTextBox_jiqima = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_input = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.xiehui = new System.Windows.Forms.RichTextBox();
            this.fangcun = new System.Windows.Forms.RichTextBox();
            this.zhixing = new System.Windows.Forms.RichTextBox();
            this.yima = new System.Windows.Forms.RichTextBox();
            this.quzhi = new System.Windows.Forms.RichTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.weizhiling = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_danbu = new System.Windows.Forms.Button();
            this.btn_last = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.zhilingchuncun = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.R1 = new System.Windows.Forms.TextBox();
            this.R2 = new System.Windows.Forms.TextBox();
            this.R3 = new System.Windows.Forms.TextBox();
            this.R4 = new System.Windows.Forms.TextBox();
            this.R5 = new System.Windows.Forms.TextBox();
            this.R6 = new System.Windows.Forms.TextBox();
            this.R7 = new System.Windows.Forms.TextBox();
            this.textBox_PC = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.R0 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.H = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox_input
            // 
            this.richTextBox_input.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox_input.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_input.Location = new System.Drawing.Point(3, 21);
            this.richTextBox_input.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox_input.Name = "richTextBox_input";
            this.richTextBox_input.ReadOnly = true;
            this.richTextBox_input.Size = new System.Drawing.Size(227, 316);
            this.richTextBox_input.TabIndex = 0;
            this.richTextBox_input.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.richTextBox_input);
            this.groupBox1.Location = new System.Drawing.Point(15, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(233, 340);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "指令导入";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.richTextBox_jiqima);
            this.groupBox2.Controls.Add(this.richTextBox3);
            this.groupBox2.Location = new System.Drawing.Point(254, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(233, 340);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "机器码";
            // 
            // richTextBox_jiqima
            // 
            this.richTextBox_jiqima.AcceptsTab = true;
            this.richTextBox_jiqima.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox_jiqima.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_jiqima.HideSelection = false;
            this.richTextBox_jiqima.Location = new System.Drawing.Point(3, 21);
            this.richTextBox_jiqima.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox_jiqima.Name = "richTextBox_jiqima";
            this.richTextBox_jiqima.ReadOnly = true;
            this.richTextBox_jiqima.Size = new System.Drawing.Size(227, 316);
            this.richTextBox_jiqima.TabIndex = 1;
            this.richTextBox_jiqima.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox3.Location = new System.Drawing.Point(3, 21);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(227, 316);
            this.richTextBox3.TabIndex = 0;
            this.richTextBox3.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 360);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "PC";
            // 
            // btn_input
            // 
            this.btn_input.Location = new System.Drawing.Point(254, 720);
            this.btn_input.Name = "btn_input";
            this.btn_input.Size = new System.Drawing.Size(101, 35);
            this.btn_input.TabIndex = 4;
            this.btn_input.Text = "导入";
            this.btn_input.UseVisualStyleBackColor = true;
            this.btn_input.Click += new System.EventHandler(this.btn_input_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.AutoSize = true;
            this.groupBox4.Controls.Add(this.xiehui);
            this.groupBox4.Controls.Add(this.fangcun);
            this.groupBox4.Controls.Add(this.zhixing);
            this.groupBox4.Controls.Add(this.yima);
            this.groupBox4.Controls.Add(this.quzhi);
            this.groupBox4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(492, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(239, 343);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "流水线（取指、译码、执行、访存、写回）";
            // 
            // xiehui
            // 
            this.xiehui.BackColor = System.Drawing.SystemColors.Control;
            this.xiehui.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.xiehui.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.xiehui.Location = new System.Drawing.Point(32, 285);
            this.xiehui.Name = "xiehui";
            this.xiehui.Size = new System.Drawing.Size(164, 34);
            this.xiehui.TabIndex = 19;
            this.xiehui.Text = "     写回";
            // 
            // fangcun
            // 
            this.fangcun.BackColor = System.Drawing.SystemColors.Control;
            this.fangcun.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fangcun.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.fangcun.Location = new System.Drawing.Point(32, 220);
            this.fangcun.Name = "fangcun";
            this.fangcun.Size = new System.Drawing.Size(164, 34);
            this.fangcun.TabIndex = 18;
            this.fangcun.Text = "     访存";
            // 
            // zhixing
            // 
            this.zhixing.BackColor = System.Drawing.SystemColors.Control;
            this.zhixing.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.zhixing.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.zhixing.Location = new System.Drawing.Point(32, 164);
            this.zhixing.Name = "zhixing";
            this.zhixing.Size = new System.Drawing.Size(164, 34);
            this.zhixing.TabIndex = 17;
            this.zhixing.Text = "     执行";
            // 
            // yima
            // 
            this.yima.BackColor = System.Drawing.SystemColors.Control;
            this.yima.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.yima.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.yima.Location = new System.Drawing.Point(32, 105);
            this.yima.Name = "yima";
            this.yima.Size = new System.Drawing.Size(164, 34);
            this.yima.TabIndex = 16;
            this.yima.Text = "     译码";
            // 
            // quzhi
            // 
            this.quzhi.BackColor = System.Drawing.SystemColors.Control;
            this.quzhi.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.quzhi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.quzhi.Location = new System.Drawing.Point(32, 49);
            this.quzhi.Name = "quzhi";
            this.quzhi.Size = new System.Drawing.Size(164, 34);
            this.quzhi.TabIndex = 15;
            this.quzhi.Text = "     取指";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.weizhiling);
            this.groupBox5.Controls.Add(this.richTextBox2);
            this.groupBox5.Location = new System.Drawing.Point(492, 367);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(233, 340);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "微指令序列记录";
            // 
            // weizhiling
            // 
            this.weizhiling.BackColor = System.Drawing.SystemColors.Window;
            this.weizhiling.Dock = System.Windows.Forms.DockStyle.Fill;
            this.weizhiling.Location = new System.Drawing.Point(3, 21);
            this.weizhiling.Margin = new System.Windows.Forms.Padding(5);
            this.weizhiling.Name = "weizhiling";
            this.weizhiling.Size = new System.Drawing.Size(227, 316);
            this.weizhiling.TabIndex = 1;
            this.weizhiling.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.Location = new System.Drawing.Point(3, 21);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(227, 316);
            this.richTextBox2.TabIndex = 0;
            this.richTextBox2.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(737, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(711, 748);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // btn_danbu
            // 
            this.btn_danbu.Location = new System.Drawing.Point(433, 720);
            this.btn_danbu.Name = "btn_danbu";
            this.btn_danbu.Size = new System.Drawing.Size(94, 35);
            this.btn_danbu.TabIndex = 2;
            this.btn_danbu.Text = "单步执行";
            this.btn_danbu.UseVisualStyleBackColor = true;
            this.btn_danbu.Click += new System.EventHandler(this.btn_danbu_Click);
            // 
            // btn_last
            // 
            this.btn_last.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_last.Location = new System.Drawing.Point(594, 720);
            this.btn_last.Name = "btn_last";
            this.btn_last.Size = new System.Drawing.Size(94, 35);
            this.btn_last.TabIndex = 15;
            this.btn_last.Text = "最终执行";
            this.btn_last.UseVisualStyleBackColor = true;
            this.btn_last.Click += new System.EventHandler(this.btn_last_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.zhilingchuncun);
            this.groupBox6.Location = new System.Drawing.Point(257, 370);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(227, 337);
            this.groupBox6.TabIndex = 18;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "指令储存单元";
            // 
            // zhilingchuncun
            // 
            this.zhilingchuncun.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zhilingchuncun.Location = new System.Drawing.Point(3, 21);
            this.zhilingchuncun.Name = "zhilingchuncun";
            this.zhilingchuncun.Size = new System.Drawing.Size(221, 313);
            this.zhilingchuncun.TabIndex = 0;
            this.zhilingchuncun.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "R1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "R2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "R3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "R4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "R5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 276);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "R6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 314);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "R7";
            // 
            // R1
            // 
            this.R1.Location = new System.Drawing.Point(65, 61);
            this.R1.Name = "R1";
            this.R1.Size = new System.Drawing.Size(100, 25);
            this.R1.TabIndex = 7;
            this.R1.Text = "0f";
            // 
            // R2
            // 
            this.R2.Location = new System.Drawing.Point(65, 102);
            this.R2.Name = "R2";
            this.R2.Size = new System.Drawing.Size(100, 25);
            this.R2.TabIndex = 8;
            this.R2.Text = "0f";
            // 
            // R3
            // 
            this.R3.Location = new System.Drawing.Point(65, 144);
            this.R3.Name = "R3";
            this.R3.Size = new System.Drawing.Size(100, 25);
            this.R3.TabIndex = 9;
            this.R3.Text = "0f";
            // 
            // R4
            // 
            this.R4.Location = new System.Drawing.Point(65, 191);
            this.R4.Name = "R4";
            this.R4.Size = new System.Drawing.Size(100, 25);
            this.R4.TabIndex = 10;
            this.R4.Text = "0f";
            // 
            // R5
            // 
            this.R5.Location = new System.Drawing.Point(65, 231);
            this.R5.Name = "R5";
            this.R5.Size = new System.Drawing.Size(100, 25);
            this.R5.TabIndex = 11;
            this.R5.Text = "0f";
            // 
            // R6
            // 
            this.R6.Location = new System.Drawing.Point(65, 273);
            this.R6.Name = "R6";
            this.R6.Size = new System.Drawing.Size(100, 25);
            this.R6.TabIndex = 12;
            this.R6.Text = "0f";
            // 
            // R7
            // 
            this.R7.Location = new System.Drawing.Point(65, 311);
            this.R7.Name = "R7";
            this.R7.Size = new System.Drawing.Size(100, 25);
            this.R7.TabIndex = 13;
            this.R7.Text = "0f";
            // 
            // textBox_PC
            // 
            this.textBox_PC.Location = new System.Drawing.Point(65, 357);
            this.textBox_PC.Name = "textBox_PC";
            this.textBox_PC.Size = new System.Drawing.Size(162, 25);
            this.textBox_PC.TabIndex = 15;
            this.textBox_PC.Text = "1000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "R0";
            // 
            // R0
            // 
            this.R0.Location = new System.Drawing.Point(65, 21);
            this.R0.Name = "R0";
            this.R0.Size = new System.Drawing.Size(100, 25);
            this.R0.TabIndex = 18;
            this.R0.Text = "0f";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.H);
            this.groupBox3.Controls.Add(this.R0);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.textBox_PC);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.R7);
            this.groupBox3.Controls.Add(this.R6);
            this.groupBox3.Controls.Add(this.R5);
            this.groupBox3.Controls.Add(this.R4);
            this.groupBox3.Controls.Add(this.R3);
            this.groupBox3.Controls.Add(this.R2);
            this.groupBox3.Controls.Add(this.R1);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(15, 370);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(236, 464);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "寄存器";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(70, 386);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 15);
            this.label11.TabIndex = 21;
            this.label11.Text = "H";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 409);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 15);
            this.label10.TabIndex = 20;
            this.label10.Text = "psw";
            // 
            // H
            // 
            this.H.Location = new System.Drawing.Point(65, 406);
            this.H.Name = "H";
            this.H.Size = new System.Drawing.Size(22, 25);
            this.H.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(98, 386);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 15);
            this.label12.TabIndex = 23;
            this.label12.Text = "S";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(93, 406);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(22, 25);
            this.textBox1.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(126, 386);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 15);
            this.label13.TabIndex = 25;
            this.label13.Text = "V";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(121, 406);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(22, 25);
            this.textBox2.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(154, 386);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 15);
            this.label14.TabIndex = 27;
            this.label14.Text = "N";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(149, 406);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(22, 25);
            this.textBox3.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(182, 386);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 15);
            this.label15.TabIndex = 29;
            this.label15.Text = "Z";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(177, 406);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(22, 25);
            this.textBox4.TabIndex = 28;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(855, 422);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 15);
            this.label16.TabIndex = 23;
            this.label16.Text = "H";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(850, 442);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(22, 25);
            this.textBox5.TabIndex = 22;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(210, 386);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 15);
            this.label17.TabIndex = 31;
            this.label17.Text = "C";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(205, 406);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(22, 25);
            this.textBox6.TabIndex = 30;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1723, 888);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.btn_last);
            this.Controls.Add(this.btn_danbu);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btn_input);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "cpu模型机_lxh";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox_input;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox richTextBox_jiqima;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Button btn_input;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox weizhiling;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RichTextBox xiehui;
        private System.Windows.Forms.RichTextBox fangcun;
        private System.Windows.Forms.RichTextBox zhixing;
        private System.Windows.Forms.RichTextBox yima;
        private System.Windows.Forms.RichTextBox quzhi;
        private System.Windows.Forms.Button btn_danbu;
        private System.Windows.Forms.Button btn_last;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RichTextBox zhilingchuncun;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox R1;
        private System.Windows.Forms.TextBox R2;
        private System.Windows.Forms.TextBox R3;
        private System.Windows.Forms.TextBox R4;
        private System.Windows.Forms.TextBox R5;
        private System.Windows.Forms.TextBox R6;
        private System.Windows.Forms.TextBox R7;
        private System.Windows.Forms.TextBox textBox_PC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox R0;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox H;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox5;
    }
}

